# hq-browser server direct install

This package is for deployed servers that do not have the development `apps/chrome` tree.

## Dry run

```bash
bash install-hq-browser-server.sh hermes-agent chrome-use-relay dry-run
```

## Install

```bash
bash install-hq-browser-server.sh hermes-agent chrome-use-relay install
```

For other profiles, pass the matching containers, for example:

```bash
bash install-hq-browser-server.sh hermes-agent-pm chrome-use-relay-pm install
bash install-hq-browser-server.sh hermes-agent-coder chrome-use-relay-coder install
bash install-hq-browser-server.sh hermes-agent-cao chrome-use-relay-cao install
```

The installer reads `CHROME_USE_CLIENT_TOKEN` from the relay container and writes the default CDP URL inside the Hermes container at `/opt/data/.config/hq-browser/cdp-url`.

No token is stored in this package.
