#!/usr/bin/env bash
set -euo pipefail

HERMES_CONTAINER="${1:-hermes-agent}"
RELAY_CONTAINER="${2:-chrome-use-relay}"
ACTION="${3:-install}"
BIN_DIR="${HUAQING_BROWSER_BIN_DIR:-/opt/data/.local/bin}"
CONFIG_DIR="${HUAQING_BROWSER_CONFIG_DIR:-/opt/data/.config/hq-browser}"

if ! docker inspect "$HERMES_CONTAINER" >/dev/null 2>&1; then
  echo "Hermes container not found: $HERMES_CONTAINER" >&2
  exit 2
fi
if ! docker inspect "$RELAY_CONTAINER" >/dev/null 2>&1; then
  echo "Relay container not found: $RELAY_CONTAINER" >&2
  exit 2
fi

CLIENT_TOKEN="$(docker inspect "$RELAY_CONTAINER" --format '{{range .Config.Env}}{{println .}}{{end}}' | sed -n 's/^CHROME_USE_CLIENT_TOKEN=//p' | sed -n '1p')"
RELAY_PORT="$(docker inspect "$RELAY_CONTAINER" --format '{{range .Config.Env}}{{println .}}{{end}}' | sed -n 's/^CHROME_USE_RELAY_PORT=//p' | sed -n '1p')"
RELAY_PORT="${RELAY_PORT:-8787}"

if [ -z "$CLIENT_TOKEN" ]; then
  echo "CHROME_USE_CLIENT_TOKEN not found in $RELAY_CONTAINER env" >&2
  exit 3
fi

CDP_URL="ws://${RELAY_CONTAINER}:${RELAY_PORT}/cdp?token=${CLIENT_TOKEN}"

COMMON_NETWORKS="$(python3 - "$HERMES_CONTAINER" "$RELAY_CONTAINER" <<'PY'
import json, subprocess, sys
h, r = sys.argv[1:3]
def nets(c):
    out = subprocess.check_output(['docker','inspect',c,'--format','{{json .NetworkSettings.Networks}}'], text=True)
    return set(json.loads(out).keys())
print(' '.join(sorted(nets(h) & nets(r))))
PY
)"

if [ -z "$COMMON_NETWORKS" ]; then
  echo "Warning: $HERMES_CONTAINER and $RELAY_CONTAINER do not share a Docker network" >&2
fi

if [ "$ACTION" = "dry-run" ]; then
  echo "Hermes container: $HERMES_CONTAINER"
  echo "Relay container: $RELAY_CONTAINER"
  echo "Common networks: ${COMMON_NETWORKS:-<none>}"
  echo "CDP URL: ws://${RELAY_CONTAINER}:${RELAY_PORT}/cdp?token=<redacted>"
  docker exec "$HERMES_CONTAINER" sh -lc "curl -m 5 -fsS http://${RELAY_CONTAINER}:${RELAY_PORT}/healthz || true"
  exit 0
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if [ ! -f "$SCRIPT_DIR/hq-browser" ]; then
  echo "Missing hq-browser next to installer: $SCRIPT_DIR/hq-browser" >&2
  exit 4
fi

docker exec "$HERMES_CONTAINER" sh -lc "mkdir -p '$BIN_DIR' '$CONFIG_DIR'"
docker cp "$SCRIPT_DIR/hq-browser" "$HERMES_CONTAINER:$BIN_DIR/hq-browser"
docker exec "$HERMES_CONTAINER" sh -lc "printf '%s\n' '$CDP_URL' > '$CONFIG_DIR/cdp-url' && chmod 600 '$CONFIG_DIR/cdp-url' && chmod +x '$BIN_DIR/hq-browser' && chown -R hermes:hermes /opt/data/.local /opt/data/.config 2>/dev/null || true && rm -rf /tmp/hq-browser-locks /tmp/hq-browser-locks-*"

echo "Installed hq-browser into $HERMES_CONTAINER:$BIN_DIR/hq-browser"
echo "Default CDP URL: ws://${RELAY_CONTAINER}:${RELAY_PORT}/cdp?token=<redacted>"
echo "Verify with: docker exec -it $HERMES_CONTAINER $BIN_DIR/hq-browser get url"
